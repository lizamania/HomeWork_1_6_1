package campany;

public enum WeaponType {
    SCAR,
    AK47,
    AWM
}
